PATTERNS=$1
grep -n -o -w -E -f $PATTERNS | \
tr ':' '\t'
